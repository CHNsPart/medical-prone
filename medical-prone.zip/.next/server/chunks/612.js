"use strict";
exports.id = 612;
exports.ids = [612];
exports.modules = {

/***/ 5612:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/rightArrow.2f70362e.svg","height":31,"width":32,"blurWidth":0,"blurHeight":0});

/***/ })

};
;